// network_emulator - simple localhost TCP proxy that injects latency/jitter.
// No admin rights required (no drivers, plain Winsock2).
//
// Usage:
//   network_emulator --latency 100 --jitter 25 --map "5001:6001;5002:6002"
//
// Options:
//   --latency N        Base delay in ms applied in both directions
//   --jitter N         Random +/- variation added to each delay (default 0)
//   --map L:T          Listen on 127.0.0.1:L, forward to 127.0.0.1:T
//                      Accepts a ';'-separated list, e.g. "5001:6001;5002:6002",
//                      and/or may be repeated. Also supports L:HOST:T.
//   --help             Show usage

#include <winsock2.h>
#include <ws2tcpip.h>
#include <timeapi.h>  // timeBeginPeriod/timeEndPeriod for accurate sleeps

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <mutex>
#include <random>
#include <string>
#include <thread>
#include <vector>

namespace {
    struct PortMap {
        std::uint16_t listen_port = 0;
        std::string target_host = "127.0.0.1";
        std::uint16_t target_port = 0;
    };

    struct Config {
        int latency_ms = 0; // applied in both directions
        int jitter_ms = 0;
        std::vector<PortMap> maps;
    };

    std::atomic g_running{true};
    std::mutex g_log_mutex;
    std::mutex g_listen_mutex;
    std::vector<SOCKET> g_listen_sockets;

    void log(const std::string &msg) {
        std::lock_guard lock(g_log_mutex);
        std::cout << msg << std::endl;
    }

    BOOL WINAPI console_ctrl_handler(DWORD ctrl_type) {
        if (ctrl_type == CTRL_C_EVENT || ctrl_type == CTRL_CLOSE_EVENT) {
            g_running = false;
            std::lock_guard lock(g_listen_mutex);
            for (SOCKET s: g_listen_sockets)
                closesocket(s); // unblocks accept()
            return TRUE;
        }
        return FALSE;
    }

    bool parse_u16(const std::string &s, std::uint16_t &out) {
        if (s.empty())
            return false;
        long v = std::strtol(s.c_str(), nullptr, 10);
        if (v <= 0 || v > 65535)
            return false;
        out = static_cast<std::uint16_t>(v);
        return true;
    }

    bool parse_map(const std::string &arg, PortMap &out) {
        // forms: L:T  or  L:HOST:T
        const auto first = arg.find(':');
        const auto last = arg.rfind(':');
        if (first == std::string::npos)
            return false;
        if (!parse_u16(arg.substr(0, first), out.listen_port))
            return false;
        if (first == last) {
            out.target_host = "127.0.0.1";
            return parse_u16(arg.substr(first + 1), out.target_port);
        }
        out.target_host = arg.substr(first + 1, last - first - 1);
        return !out.target_host.empty() && parse_u16(arg.substr(last + 1), out.target_port);
    }

    void print_usage(const char *exe) {
        std::cout <<
                "Usage: " << exe << " [options] --map \"L:T[;L:T ...]\"\n"
                "\n"
                "Listens on 127.0.0.1:L and forwards to T (default host 127.0.0.1),\n"
                "injecting latency. Point your client at L instead of T. No admin needed.\n"
                "\n"
                "Options:\n"
                "  --latency N        Base delay in ms, both directions\n"
                "  --jitter N         Random +/- ms variation per chunk (default 0)\n"
                "  --map L:T          Port mapping. Accepts a ';'-separated list\n"
                "                     (quote it in most shells) and/or may be repeated.\n"
                "                     Also supports L:HOST:T.\n"
                "  --help             Show this help\n"
                "\n"
                "Example:\n"
                "  " << exe << " --latency 100 --jitter 25 --map \"5001:6001;5002:6002\"\n";
    }

    bool parse_args(int argc, char **argv, Config &cfg) {
        for (int i = 1; i < argc; ++i) {
            const std::string a = argv[i];
            auto next_int = [&](int &out) -> bool {
                if (i + 1 >= argc)
                    return false;
                out = std::atoi(argv[++i]);
                return out >= 0;
            };
            if (a == "--help" || a == "-h") {
                print_usage(argv[0]);
                std::exit(0);
            } else if (a == "--latency") {
                if (!next_int(cfg.latency_ms)) return false;
            } else if (a == "--jitter") {
                if (!next_int(cfg.jitter_ms)) return false;
            } else if (a == "--map") {
                if (i + 1 >= argc) return false;
                const std::string value = argv[++i];
                // ';'-separated list of mappings, e.g. "5001:6001;5002:6002"
                size_t start = 0;
                while (start <= value.size()) {
                    const size_t end = value.find(';', start);
                    const std::string item = value.substr(start, end == std::string::npos ? end : end - start);
                    if (!item.empty()) {
                        PortMap m;
                        if (!parse_map(item, m)) {
                            std::cerr << "Invalid --map entry: " << item << "\n";
                            return false;
                        }
                        cfg.maps.push_back(std::move(m));
                    }
                    if (end == std::string::npos)
                        break;
                    start = end + 1;
                }
            } else {
                std::cerr << "Unknown option: " << a << "\n";
                return false;
            }
        }
        if (cfg.maps.empty()) {
            std::cerr << "At least one --map is required.\n";
            return false;
        }
        return true;
    }

    // Forward data from `from` to `to`, delaying each received chunk.
    void pump(SOCKET from, SOCKET to, int latency_ms, int jitter_ms, std::mt19937 &rng) {
        char buf[8 * 1024 * 1024];
        while (g_running.load()) {
            const int n = recv(from, buf, sizeof(buf), 0);
            if (n <= 0)
                break; // closed or error

            int delay = latency_ms;
            if (jitter_ms > 0) {
                std::uniform_int_distribution dist(-jitter_ms, jitter_ms);
                delay = std::max(0, delay + dist(rng));
            }
            if (delay > 0)
                std::this_thread::sleep_for(std::chrono::milliseconds(delay));

            int sent = 0;
            while (sent < n) {
                const int s = send(to, buf + sent, n - sent, 0);
                if (s <= 0) {
                    shutdown(to, SD_SEND);
                    return;
                }
                sent += s;
            }
        }
        shutdown(to, SD_SEND); // half-close: let the other pump drain
    }

    void handle_session(SOCKET client, const PortMap &map, const Config &cfg) {
        const std::string tag = "[" + std::to_string(map.listen_port) + " -> " +
                                map.target_host + ":" + std::to_string(map.target_port) + "] ";

        SOCKET target = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (target == INVALID_SOCKET) {
            closesocket(client);
            return;
        }

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(map.target_port);
        addr.sin_addr.s_addr = inet_addr(map.target_host.c_str());
        if (addr.sin_addr.s_addr == INADDR_NONE) {
            // not numeric -> resolve
            if (const hostent *he = gethostbyname(map.target_host.c_str()))
                addr.sin_addr.s_addr = *reinterpret_cast<const u_long *>(he->h_addr_list[0]);
        }
        if (connect(target, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) == SOCKET_ERROR) {
            log(tag + "connect to target failed (WSA error " + std::to_string(WSAGetLastError()) + ")");
            closesocket(target);
            closesocket(client);
            return;
        }

        log(tag + "connection established");

        std::mt19937 rng(std::random_device{}());

        std::thread up(pump, client, target, cfg.latency_ms, cfg.jitter_ms, std::ref(rng));
        std::thread down(pump, target, client, cfg.latency_ms, cfg.jitter_ms, std::ref(rng));
        up.join();
        down.join();

        closesocket(client);
        closesocket(target);
        log(tag + "connection closed");
    }

    void listener_loop(const PortMap map, const Config &cfg) {
        SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (s == INVALID_SOCKET) {
            log("socket() failed for port " + std::to_string(map.listen_port));
            return;
        }
        BOOL reuse = TRUE;
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char *>(&reuse), sizeof(reuse));

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(map.listen_port);
        addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK); // localhost only

        if (bind(s, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) == SOCKET_ERROR) {
            log("bind failed on port " + std::to_string(map.listen_port) +
                " (WSA error " + std::to_string(WSAGetLastError()) + ")");
            closesocket(s);
            return;
        }
        if (listen(s, SOMAXCONN) == SOCKET_ERROR) {
            closesocket(s);
            return;
        }
        {
            std::lock_guard lock(g_listen_mutex);
            g_listen_sockets.push_back(s);
        }
        log("Listening on 127.0.0.1:" + std::to_string(map.listen_port) + " -> " +
            map.target_host + ":" + std::to_string(map.target_port));

        while (g_running.load()) {
            SOCKET client = accept(s, nullptr, nullptr);
            if (client == INVALID_SOCKET)
                break; // socket closed on shutdown
            std::thread(handle_session, client, map, std::cref(cfg)).detach();
        }
    }
} // namespace

int main(int argc, char **argv) {
    Config cfg;
    if (!parse_args(argc, argv, cfg)) {
        print_usage(argv[0]);
        return 1;
    }

    WSADATA wsa{};
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        std::cerr << "WSAStartup failed\n";
        return 1;
    }
    SetConsoleCtrlHandler(console_ctrl_handler, TRUE);
    timeBeginPeriod(1); // ~1ms sleep resolution instead of the default ~15.6ms

    std::cout << "Latency: " << cfg.latency_ms << " ms, jitter: " << cfg.jitter_ms << " ms\n";

    std::vector<std::thread> listeners;
    listeners.reserve(cfg.maps.size());
    for (const PortMap &m: cfg.maps)
        listeners.emplace_back(listener_loop, m, std::cref(cfg));

    for (auto &t: listeners)
        t.join();

    std::cout << "Shutting down.\n";
    timeEndPeriod(1);
    WSACleanup();
    return 0;
}
